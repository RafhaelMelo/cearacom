# iOS Tests for CDVSplashScreen

You need to install `node.js` to pull in `cordova-ios`.

First install cordova-ios:

    npm install

... in the current folder.


# Testing from Xcode

1. Launch the `CDVSplashScreenTest.xcworkspace` file.
2. Choose "CDVSplashScreenLibTests" from the scheme drop-down menu
3. Click and hold on the `Play` button, and choose the `Wrench` icon to run the tests


# Testing from the command line

    npm test
